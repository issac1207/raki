﻿namespace AutoInsurance_Web_Api.Models
{
    public class RejectRequestViewModel
    {
        public string status { get; set; }
    }
}
