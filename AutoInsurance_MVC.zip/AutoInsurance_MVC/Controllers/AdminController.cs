﻿using AutoInsurance_MVC.Models;
using AutoInsurance_Web_Api.Models;
using AutoInsurance_MVC.Models;
using Microsoft.AspNetCore.Mvc;

using Newtonsoft.Json;

using System.Text;

namespace AutoInsurance_MVC.Controllers

{

    public class AdminController : Controller

    {

        [BindProperty]

        public UserViewModel uvm { get; set; }

        [BindProperty]

        public Claim Claim { get; set; }

        [BindProperty]

        public VehicleDetails vehicleDetails { get; set; }

        [BindProperty]

        public User user { get; set; }
        [BindProperty]
        public ApproveRequestViewModel approveRequest { get; set; }
        [BindProperty]
        ApprovedClaimReport approvedClaimReport { get; set; }


        public IActionResult Index()

        {

            return View();

        }

        public async Task<IActionResult> ClaimList()

        {

            List<Claim> claim = new List<Claim>();

            using (var httpClient = new HttpClient())

            {

                using (var response = await httpClient.GetAsync("http://localhost:61913/Admin/ClaimList"))

                {

                    var apiResponse = await response.Content.ReadAsStringAsync();

                    claim = JsonConvert.DeserializeObject<List<Claim>>(apiResponse);

                }

            }

            return View(claim);

        }

        public async Task<IActionResult> VehicleDetails(int id)

        {

            VehicleDetails vehicledetails = null;

            using (var httpClient = new HttpClient())

            {

                using (var response = await httpClient.GetAsync("http://localhost:61913/Admin/" + id))

                {

                    var apiResponse = await response.Content.ReadAsStringAsync();

                    vehicledetails = JsonConvert.DeserializeObject<VehicleDetails>(apiResponse);

                }

            }

            return View(vehicledetails);

        }

        public async Task<IActionResult> CustomerDetails(int id)

        {

            User user = null;

            using (var httpClient = new HttpClient())

            {

                using (var response = await httpClient.GetAsync("http://localhost:61913/Admin/CustomerID/" + id))

                {

                    var apiResponse = await response.Content.ReadAsStringAsync();

                    user = JsonConvert.DeserializeObject<User>(apiResponse);

                }

            }

            return View(user);

        }

        public async Task<IActionResult> UserDetails(int id, int id2)

        {

            UserViewModel user = null;

            using (var httpClient = new HttpClient())

            {

                using (var response = await httpClient.GetAsync("http://localhost:61913/Admin/CustomerID/" + id))

                {

                    var apiResponse = await response.Content.ReadAsStringAsync();

                    user = JsonConvert.DeserializeObject<UserViewModel>(apiResponse);

                }

            }

            //ViewData["Message"] = id2;

            ViewBag.Name = id2;

            return View(user);

        }

      

        public async Task<IActionResult> Approve(int id)

        {

            using (var httpClient = new HttpClient())

            {
                //StringContent content = new StringContent(JsonConvert.SerializeObject(Claim), Encoding.UTF8, "application/json");
               using (var response = await httpClient.GetAsync("http://localhost:61913/Admin/rakesh/"+id+"/Approved"))
                {

                    if (response.IsSuccessStatusCode)

                   {

                        var responseText = response.Content.ReadAsStringAsync().Result;
                        return View(ClaimList);

                    }

                }

           }

            return View(ClaimList);

        }
        public async Task<IActionResult> Reject(int id)

        {

            using (var httpClient = new HttpClient())

            {
                //StringContent content = new StringContent(JsonConvert.SerializeObject(Claim), Encoding.UTF8, "application/json");
                using (var response = await httpClient.GetAsync("http://localhost:61913/Admin/rakesh/" + id + "/Rejected"))
                {

                    if (response.IsSuccessStatusCode)

                    {

                        var responseText = response.Content.ReadAsStringAsync().Result;
                        return View(ClaimList);

                    }

                }

            }

            return View(ClaimList);

        }
        [HttpGet]
        public async Task<IActionResult> ApprovedClaimReport()

        {

            List<ApprovedClaimReport> ACR = new List<ApprovedClaimReport>();

            using (var httpClient = new HttpClient())

            {

                using (var response = await httpClient.GetAsync("http://localhost:61913/Admin/ApprovedClaimReport"))

                {

                    var apiResponse = await response.Content.ReadAsStringAsync();

                    ACR = JsonConvert.DeserializeObject<List<ApprovedClaimReport>>(apiResponse);

                }

            }

            return View(ACR);

        }
        [HttpGet]
        public async Task<IActionResult> RejectedClaimReport()

        {

            List<RejectedClaimReport> RCR = new List<RejectedClaimReport>();

            using (var httpClient = new HttpClient())

            {

                using (var response = await httpClient.GetAsync("http://localhost:61913/Admin/RejectedClaimReport"))

                {

                    var apiResponse = await response.Content.ReadAsStringAsync();

                    RCR = JsonConvert.DeserializeObject<List<RejectedClaimReport>>(apiResponse);

                }

            }

            return View(RCR);

        }

        public IActionResult SearchById()
        {
            return View();
        }
        public async Task<IActionResult> SearchByIds(int id)

        {
            using (var httpClient = new HttpClient())
            {
            using (var response = await httpClient.GetAsync("http://localhost:61913/Admin/ClaimById/"+id))
                {
                    var apiResponse = await response.Content.ReadAsStringAsync();
                    return RedirectToAction("Result", new { m = apiResponse });
                }
            }
            return View();
        }
        public IActionResult Result(string m)
        {
            ViewBag.Name = m;
            return View();
        }
    }

}

