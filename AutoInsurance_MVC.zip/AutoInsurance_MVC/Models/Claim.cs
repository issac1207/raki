﻿using System.ComponentModel.DataAnnotations;

using System.ComponentModel.DataAnnotations.Schema;

namespace AutoInsurance_MVC.Models

{

    public class Claim

    {
        public int ClaimId { get; set; }
        [Required]
        public int VehicleId { get; set; }
        [Required]
        public DateTime ClaimDate { get; set; }
        [Required]
        public float ClaimAmount { get; set; }
        [Required]
        public string NatureOfClaim { get; set; }
        [Required]
        public string Status { get; set; }


    }

}

