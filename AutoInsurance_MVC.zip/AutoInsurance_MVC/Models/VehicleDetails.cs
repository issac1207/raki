﻿using System.ComponentModel.DataAnnotations;

using System.ComponentModel.DataAnnotations.Schema;

namespace AutoInsurance_MVC.Models
{
    public class VehicleDetails
    {
        public int VehicleId { get; set; }
        public int CustomerId { get; set; }
        //public string Make { get; set; }
        public string Model { get; set; }
        public int Year { get; set; }
        public int Price { get; set; }
    }
}