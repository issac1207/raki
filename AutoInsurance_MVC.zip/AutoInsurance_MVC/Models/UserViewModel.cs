﻿using System.ComponentModel.DataAnnotations;

namespace AutoInsurance_MVC.Models

{

    public class UserViewModel

    {

        public int UserId { get; set; }

        [Required]

        public string FirstName { get; set; }

        [Required]

        public string LastName { get; set; }

        [Required]

        public string Address { get; set; }

        [Required]

        public string Email { get; set; }

        [Required]

        public ulong Contact { get; set; }

        public int VehicleId { get; set; }

    }

}

