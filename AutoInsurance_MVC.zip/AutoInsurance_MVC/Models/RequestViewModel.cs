﻿namespace AutoInsurance_MVC.Models

{

    public class RequestViewModel

    {

        public string Pending { get; set; }

    }

}